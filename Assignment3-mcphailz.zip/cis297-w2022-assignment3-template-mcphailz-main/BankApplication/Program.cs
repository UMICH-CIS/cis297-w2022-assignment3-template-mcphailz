﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
///  Name: Charles McPhail
///  Semester: Winter 2022
///  Class: CIS 297
///  Date: 2/9/2022
///  Assignment 3
/// </summary>


namespace BankApplication
{
    /// <summary>
    /// Class Account: Base class that holds balance, and basic credit and debit methods.
    /// </summary>
    class Account
    {
        private decimal balance;

        /// <summary>
        /// Default constructor of Account.
        /// </summary>
        public Account()
        {
            balance = 0;
        }

        /// <summary>
        /// Parameterized Constructor of Account.
        /// </summary>
        /// <param name="initialBalance"></param>
        public Account(decimal initialBalance)
        {
            if (initialBalance < 0)
            {
                throw new InvalidOperationException("Balance needs to be greater than or equal to 0.");
            }
            else
            {
                balance = initialBalance;
            }
         
        }
        /// <summary>
        /// Credit Method: Increases account balance.
        /// </summary>
        /// <param name="amount"></param>
        virtual public void Credit(decimal amount)
        {
            balance = balance + amount;
        }
        /// <summary>
        /// Debit Method: Decreases account balance if new balance >= 0. 
        /// </summary>
        /// <param name="amount"></param>
        virtual public bool Debit(decimal amount)
        {
            if(amount > balance)
            {
                Console.WriteLine("Debit amount exceeded account balance");
                return false;
            }
            balance = balance - amount;
            return true;
        }

        /// <summary>
        /// Returns current balance.
        /// </summary>
        /// <returns></returns>
        public decimal GetBalance()
        {
            return balance;
        }

        
    }

    /// <summary>
    /// Class SavingsAccount: Child of Account Class; Applies interest to balance.
    /// </summary>
    class SavingsAccount : Account
    {
        private decimal interest;

        /// <summary>
        /// Default constructor of SavingsAccount.
        /// </summary>
        public SavingsAccount()
        {
            interest = 0;
        }

        /// <summary>
        /// Parameterized Constructor of SavingsAccount.
        /// </summary>
        /// <param name="initialBalance"></param>
        /// <param name="initialInterest"></param>
        public SavingsAccount(decimal initialBalance, decimal initialInterest) : base(initialBalance) 
        {
            interest = initialInterest;
        }

        /// <summary>
        /// Returns balance multiplied by interest.
        /// </summary>
        /// <returns></returns>
        public decimal CalculateInterest()
        {
            return GetBalance() * interest;
        }
    }
    /// <summary>
    /// Class CheckingAccount: Child of Account Class; Applies fee to Credit and Debit methods.
    /// </summary>
    class CheckingAccount : Account
    {
        private decimal fee;

        /// <summary>
        /// CheckingAccount default constructor.
        /// </summary>
        CheckingAccount()
        {
            fee = 0;
        }

        /// <summary>
        /// Parameterized constructor for CheckingAccount.
        /// </summary>
        /// <param name="initialBalance"></param>
        /// <param name="feeAmount"></param>
        public CheckingAccount(decimal initialBalance, decimal feeAmount) : base(initialBalance)
        {
            fee = feeAmount;
        }

        /// <summary>
        /// Modified Credit: Credits account and deducts fee, but only if the new balance is greater than or equal to the fee. 
        /// </summary>
        /// <param name="amount"></param>
        public new void Credit(decimal amount)
        {
            if ((amount + GetBalance()) >= fee)
            {
                base.Credit(amount);
                base.Debit(fee);
            }
            else
            {
                Console.WriteLine("Credit declined: New balance is less than fee.");
            }
        }
        /// <summary>
        /// Modified Debit: Debits account with fee.
        /// </summary>
        /// <param name="amount"></param>
        /// <returns></returns>
        public new bool Debit(decimal amount)
        {
            if (base.Debit(amount + fee))
            {
                return true;
            }
            Console.WriteLine("Debit declined: Not enough remaining funds to afford fee.");
            return false;
        }

    }

    /// <summary>
    /// Driver Class.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Ch.11 Testing
            Account ac = new Account(100);
            SavingsAccount sa = new SavingsAccount(100, 0.25M);
            CheckingAccount ca = new CheckingAccount(100, 5);
            Console.WriteLine("Ch.11 Testing: ");

            Console.WriteLine("Account's Balance: {0}", ac.GetBalance());
            ac.Credit(100);
            Console.WriteLine("Account's Balance after using Credit: {0}", ac.GetBalance());
            ac.Debit(50);
            Console.WriteLine("Account's Balance after using Debit: {0}", ac.GetBalance());

            Console.WriteLine("Saving's Balance: {0}", sa.GetBalance());
            sa.Credit(sa.CalculateInterest());
            Console.WriteLine("Saving's Balance after interest: {0}", sa.GetBalance());

            Console.WriteLine("Checking's Balance: {0}", ca.GetBalance());
            ca.Credit(100);
            Console.WriteLine("Checking's Balance after using Credit w/ fee: {0}", ca.GetBalance());
            ca.Debit(50);
            Console.WriteLine("Checking's Balance after using Debit w/ fee: {0}", ca.GetBalance());

            // 12.13 Hierarchy
            Console.WriteLine("\n12.13 Hierarchy: ");
            Account[] accounts = new Account[] { new SavingsAccount(100, 0.25M), new CheckingAccount(100, 5) };

            decimal GetInput() => decimal.Parse(Console.ReadLine());

            for(int i = 0; i < 2; i++)
            {
                var account = accounts[i];
                Console.WriteLine("Account Type: {0}", account.GetType().Name);
                decimal deb = 0;
                decimal cred = 0;

                Console.WriteLine("Enter amount to withdraw (Debit):");
                deb = GetInput();

                Console.WriteLine("Enter amount to deposit (Credit):");
                cred = GetInput();

                if (account.GetType().Name == "SavingsAccount")
                {
                    SavingsAccount savings = (SavingsAccount)account;
                    savings.Debit(deb);
                    savings.Credit(cred);
                    account.Credit(savings.CalculateInterest());
                }
                else if(account.GetType().Name == "CheckingAccount")
                {
                    CheckingAccount checking = (CheckingAccount)account;
                    checking.Debit(deb);
                    checking.Credit(cred);
                }

                Console.WriteLine("Account Balance: {0}", account.GetBalance());
            }

            Console.WriteLine("Press a key to close.");
            Console.ReadLine();
        }
    }
}
